Czech Translation (cs-CZ) for
Attachments for Articles Extension for Joomla 1.5
(http://joomlacode.org/gf/project/attachments/)

Translation by: Tomas Udrzal 

For Attachments version 1.3.3
Last updated: February 2009
Status: Complete except for help file

INSTALLATION:
  - Unzip this file in the root directory of your website.
    This will place all of the translation files in the
    correct places.

If you have questions about this translation or want to 
assist with translations, please contact Jonathan Cameron
(jmcameron@jmcameron.net).

Copyright (c) 2007, 2008 Jonathan M. Cameron, All Rights Reserved
License: GNU/GPL2, http://www.gnu.org/licenses/gpl-2.0.html 

INSTALLED FILES:
    administrator/components/com_attachments/help/cs-CZ/help.css
    administrator/components/com_attachments/help/cs-CZ/help.html
    administrator/components/com_attachments/help/cs-CZ/index.html
    administrator/language/cs-CZ/cs-CZ.com_attachments.ini
    administrator/language/cs-CZ/cs-CZ.com_attachments.menu.ini
    administrator/language/cs-CZ/cs-CZ.plg_content_attachments.ini
    administrator/language/cs-CZ/cs-CZ.plg_editors-xtd_add_attachment.ini
    administrator/language/cs-CZ/cs-CZ.plg_frontend_attachments.ini
    administrator/language/cs-CZ/cs-CZ.plg_search_attachments.ini
    language/cs-CZ/cs-CZ.com_attachments.ini
